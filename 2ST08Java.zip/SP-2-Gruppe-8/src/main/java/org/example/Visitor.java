package org.example;

public class Visitor {
}
