package org.example;

public class Account {
}
